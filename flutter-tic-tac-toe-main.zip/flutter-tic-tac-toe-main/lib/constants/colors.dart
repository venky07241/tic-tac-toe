import 'package:flutter/material.dart';

class MainColor {
  static Color primaryColor = Color(0xFFff4b4b);
  static Color secondaryColor = Color(0xFFffca27);
  static Color accentColor = Color(0xFF4169e8);
}